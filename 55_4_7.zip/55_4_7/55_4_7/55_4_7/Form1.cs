﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace _55_4_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Dictionary<string, string> record = new Dictionary<string, string>();

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now.AddDays(1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != null && comboBox2.Text != null)
            {
                if (!record.ContainsKey(dateTimePicker1.Text))
                {
                    record.Add(dateTimePicker1.Text, "-" + comboBox1.Text + (radioButton1.Checked ? " 付現：是 " : " 付現：否 ") + comboBox2.Text);
                    listBox1.Items.Add(dateTimePicker1.Text + record[dateTimePicker1.Text]);
                    comboBox1.Text = comboBox2.Text = "";
                    MessageBox.Show("新增成功");
                }
                else
                {
                    MessageBox.Show("已有相同資料");
                }
            }
            else
            {
                MessageBox.Show("請選擇資料");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != null && comboBox2.Text != null)
            {
                if (record.ContainsKey(dateTimePicker1.Text))
                {
                    string[] old_rec = record[dateTimePicker1.Text].Split(' ');
                    if (old_rec.Length == 3)
                    {
                        record[dateTimePicker1.Text] = (string.IsNullOrEmpty(comboBox1.Text) ? old_rec[0] : "-" + comboBox1.Text) + (radioButton1.Checked ? " 付現：是 " : " 付現：否 ") + (string.IsNullOrEmpty(comboBox2.Text) ? old_rec[2] : comboBox2.Text);
                        listBox1.Items.Clear();
                        foreach (var items in record)
                        {
                            listBox1.Items.Add(items.Key + items.Value);
                        }
                        comboBox1.Text = comboBox2.Text = "";
                        MessageBox.Show("修改成功");
                    }
                }
                else
                {
                    MessageBox.Show("查無資料");
                }
            }
            else
            {
                MessageBox.Show("請選擇資料");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (record.ContainsKey(dateTimePicker1.Text))
            {
                listBox1.Items.Clear();
                listBox1.Items.Add(dateTimePicker1.Text + record[dateTimePicker1.Text]);
                MessageBox.Show("查詢成功");
            }
            else
            {
                MessageBox.Show("查無資料");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (var items in record)
            {
                listBox1.Items.Add(items.Key + items.Value);
            }
            MessageBox.Show("更新資料成功");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != null && comboBox2.Text != null)
            {
                if (record.ContainsKey(dateTimePicker1.Text))
                {
                    record.Remove(dateTimePicker1.Text);
                    listBox1.Items.Clear();
                    foreach (var items in record)
                    {
                        listBox1.Items.Add(items.Key + items.Value);
                    }
                    comboBox1.Text = comboBox2.Text = "";
                    MessageBox.Show("刪除成功");
                }
                else
                {
                    MessageBox.Show("查無資料");
                }
            }
            else
            {
                MessageBox.Show("請選擇資料");
            }
        }

        private void button7_Click(object sender, EventArgs e)//匯出成json
        {
            using (Database1Entities db = new Database1Entities())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    db.Table.RemoveRange(db.Table);  // 清空 Table 表
                    db.SaveChanges();
                    //List<Table> exportData = record.Select(r => new Table { date = r.Key, who = r.Value.Split(' ')[0].Replace("-",""), money = r.Value.Split(' ')[1], pay = r.Value.Split(' ')[2] }).ToList();
                    //需在專案中加入Newtonsoft.Json套件，在工具->NuGet套件管理員->套件管理器主控台中輸入Install-Package Newtonsoft.Json
                    //string json = JsonConvert.SerializeObject(exportData, Newtonsoft.Json.Formatting.Indented);
                    //string json = System.Text.Json.JsonSerializer.Serialize(exportData, new JsonSerializerOptions { WriteIndented = true });

                    var datatable = record.Select(r => new Table { date = r.Key, who = r.Value.Split(' ')[0].Replace("-", ""), money = r.Value.Split(' ')[1], pay = r.Value.Split(' ')[2] }).ToList();
                    // 新增到資料庫
                    db.Table.AddRange(datatable);
                    db.SaveChanges();  // 儲存變更
                    string json = System.Text.Json.JsonSerializer.Serialize(datatable, new JsonSerializerOptions { WriteIndented = true });

                    File.WriteAllText(openFileDialog1.FileName, json);
                    MessageBox.Show("匯出成功");
                }
            }
        }
        private void button6_Click(object sender, EventArgs e)//匯入json
        {
            using (Database1Entities db = new Database1Entities())
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    db.Table.RemoveRange(db.Table);  // 清空 Table 表
                    db.SaveChanges();
                    string json = File.ReadAllText(openFileDialog1.FileName);
                    //List<Table> importData = System.Text.Json.JsonSerializer.Deserialize<List<Table>>(json);
                    var importData = System.Text.Json.JsonSerializer.Deserialize<List<Table>>(json);
                    db.Table.AddRange(importData);
                    db.SaveChanges();  // 儲存變更

                    if (importData != null)
                    {
                        record.Clear();
                        listBox1.Items.Clear();

                        foreach (var item in importData)
                        {
                            record[item.date] = $"-{item.who} {item.money} {item.pay}";
                            listBox1.Items.Add(item.date + $"-{item.who} {item.money} {item.pay}");
                        }

                        MessageBox.Show("匯入成功");
                    }
                    else
                    {
                        MessageBox.Show("匯入失敗，格式錯誤");
                    }
                }
            }
        }
    }
}
